class NoOpSentinel: pass
